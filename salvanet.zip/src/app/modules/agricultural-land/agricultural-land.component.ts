import { Component } from '@angular/core';

@Component({
  selector: 'app-agricultural-land',
  templateUrl: './agricultural-land.component.html',
  styleUrls: ['./agricultural-land.component.css']
})
export class AgriculturalLandComponent {

}
