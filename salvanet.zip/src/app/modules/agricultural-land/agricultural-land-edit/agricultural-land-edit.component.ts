import { Component } from '@angular/core';

@Component({
  selector: 'app-agricultural-land-edit',
  templateUrl: './agricultural-land-edit.component.html',
  styleUrls: ['./agricultural-land-edit.component.css']
})
export class AgriculturalLandEditComponent {

}
