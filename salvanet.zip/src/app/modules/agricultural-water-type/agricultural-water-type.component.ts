import { Component } from '@angular/core';

@Component({
  selector: 'app-agricultural-water-type',
  templateUrl: './agricultural-water-type.component.html',
  styleUrls: ['./agricultural-water-type.component.css']
})
export class AgriculturalWaterTypeComponent {

}
