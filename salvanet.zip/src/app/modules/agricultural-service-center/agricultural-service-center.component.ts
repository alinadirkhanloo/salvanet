import { Component } from '@angular/core';

@Component({
  selector: 'app-agricultural-service-center',
  templateUrl: './agricultural-service-center.component.html',
  styleUrls: ['./agricultural-service-center.component.css']
})
export class AgriculturalServiceCenterComponent {

}
