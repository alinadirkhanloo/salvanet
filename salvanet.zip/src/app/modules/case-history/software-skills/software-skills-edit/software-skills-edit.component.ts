import { Component } from '@angular/core';

@Component({
  selector: 'app-software-skills-edit',
  templateUrl: './software-skills-edit.component.html',
  styleUrls: ['./software-skills-edit.component.css']
})
export class SoftwareSkillsEditComponent {

}
