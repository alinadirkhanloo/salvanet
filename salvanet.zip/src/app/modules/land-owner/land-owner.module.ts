import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LandOwnerRoutingModule } from './land-owner-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    LandOwnerRoutingModule
  ]
})
export class LandOwnerModule { }
