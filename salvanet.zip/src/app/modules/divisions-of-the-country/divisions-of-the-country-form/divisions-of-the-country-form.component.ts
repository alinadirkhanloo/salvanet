import { Component } from '@angular/core';

@Component({
  selector: 'app-divisions-of-the-country-form',
  templateUrl: './divisions-of-the-country-form.component.html',
  styleUrls: ['./divisions-of-the-country-form.component.css']
})
export class DivisionsOfTheCountryFormComponent {

}
