import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgriculturalInterestsComponent } from './agricultural-interests.component';

describe('AgriculturalInterestsComponent', () => {
  let component: AgriculturalInterestsComponent;
  let fixture: ComponentFixture<AgriculturalInterestsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgriculturalInterestsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AgriculturalInterestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
