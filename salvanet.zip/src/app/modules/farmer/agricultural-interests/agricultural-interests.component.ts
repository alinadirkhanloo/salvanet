import { Component } from '@angular/core';

@Component({
  selector: 'app-agricultural-interests',
  templateUrl: './agricultural-interests.component.html',
  styleUrls: ['./agricultural-interests.component.css']
})
export class AgriculturalInterestsComponent {
  disableButton=false;
  products = [
    {
      title:'fasf as asf asf asf asf asf asf'
    },
    {
      title:'fasf as asf asf asf asf asf asf'
    },
    {
      title:'fasf as asf asf asf asf asf asf'
    }
  ]
}
