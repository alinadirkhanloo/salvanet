import { Component } from '@angular/core';

@Component({
  selector: 'app-agricultural-experiences',
  templateUrl: './agricultural-experiences.component.html',
  styleUrls: ['./agricultural-experiences.component.css']
})
export class AgriculturalExperiencesComponent {
  disableButton=false;
  products = [
    {
      title:'fasf as asf asf asf asf asf asf'
    },
    {
      title:'fasf as asf asf asf asf asf asf'
    },
    {
      title:'fasf as asf asf asf asf asf asf'
    }
  ]
}
