import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgriculturalExperiencesComponent } from './agricultural-experiences.component';

describe('AgriculturalExperiencesComponent', () => {
  let component: AgriculturalExperiencesComponent;
  let fixture: ComponentFixture<AgriculturalExperiencesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgriculturalExperiencesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AgriculturalExperiencesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
