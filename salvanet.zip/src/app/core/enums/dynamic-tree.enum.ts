export enum SelectionMode
{
  NON_SELECT = '',
  SINGLE_SELECT = 'single',
  MULTI_SELECT = 'multiple',
  MULTI_SELECT_WITH_CHECKBOX = 'checkbox'
}
