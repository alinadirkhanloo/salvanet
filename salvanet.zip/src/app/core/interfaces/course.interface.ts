export interface ICource{
	title: string;
    year:string;
    duration:string;
}