export interface IEducationDegree{
	gPA: number;
	id: number;
	universityId: number;
	studyFieldId: number;
	educationLevelId: number;
	majorStudyFieldId: number;
}