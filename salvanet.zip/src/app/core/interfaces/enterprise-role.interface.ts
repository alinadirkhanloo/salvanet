export interface IEnterpriseRole{
	isSupervisor: boolean;
	maxPositionNumber: number;
	id: number;
}
