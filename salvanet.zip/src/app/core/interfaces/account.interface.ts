export interface IAccount{
	fullName ?: string;
	idNumber ?: string;
	username?: string;
	phoneNumber?: string;
	id?: string|number;
	isActive?: boolean
}
