export interface IOwner{
	fullName: string;
	id: string;
	nationalId: string;
	studyFieldId: string;
	sharePercentage: string;
	ratio: string;
}
