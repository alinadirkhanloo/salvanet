export interface IRegistrationAnnouncement {
	title: string;
	startDate: string;
	endDate: string;
	code: string;
	description: string;
	isActive: boolean;
}
