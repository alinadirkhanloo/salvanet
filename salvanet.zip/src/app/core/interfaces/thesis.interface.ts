export interface IThesis{
    title?:string;
    score?:number;
	id?: string | number;
}