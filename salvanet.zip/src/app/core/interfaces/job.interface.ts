export interface IJob{
	workPlace?: string;
	position?: string;
    startDate?:string;
    endDate?:string;
	id?: string;
}