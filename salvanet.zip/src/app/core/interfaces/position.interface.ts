export interface IPosition{
	isActive: boolean;
	roleId: number;
	holdsById: number;
}
