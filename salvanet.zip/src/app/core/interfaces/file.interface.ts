export interface IFile {
	name: string;
	displayName: string;
	createdAt: string;
	modifiedAt: string;
	size: number;
	content: number;
}