export interface IArticle{
	type: string;
	title: string;
	printYear: number;
}