export interface ITeaching{
	subject?: string;
	venue?: string;
    year?:string;
    duration?:string;
	id?: string | number;
}