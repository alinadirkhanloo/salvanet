export interface ICompany{
	name: string;
	establishmentDate: string;
	registrationDate: string;
	registrationNumber: string;
	lastRegisteredCapital: number;
	type: number;
}