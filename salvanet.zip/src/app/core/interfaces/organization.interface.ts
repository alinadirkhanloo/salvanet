export interface IOrganization {
	name: string;
	isActive: boolean;
	countryDivisionId: number;
	deploymentServerId: number;
}