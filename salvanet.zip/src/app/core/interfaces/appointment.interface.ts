export interface IAppointment{
	date: string;
	dismissalDate: string;
	positionId: number;
	personId: number;
}