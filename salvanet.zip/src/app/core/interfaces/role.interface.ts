export interface IRole {
	code: number;
	name: string;
	displayName: string;
	needsRecruitment:string ;
	isActive: boolean;
    id:number;
}


