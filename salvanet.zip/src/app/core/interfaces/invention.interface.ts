export interface IInvention {
	title: string;
	registrationNumber: string;
	id: number;
}
