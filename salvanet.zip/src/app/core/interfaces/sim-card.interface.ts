export interface ISimCard{
	phoneNumber?: string;
	isActive?: boolean;
    operator?:string;
	id?: number;
}