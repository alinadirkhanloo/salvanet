export interface IServer {
    code:string;
	name:string;
	displayName:string;
	isActive:boolean;
	address:string;
    id:number;
}


