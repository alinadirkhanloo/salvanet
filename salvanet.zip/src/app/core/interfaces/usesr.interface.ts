import { IPerson } from './person.interface';
export interface IUser extends IPerson{

}